
      var content, columns, compiledCardTemplate = undefined;
        var MIN_COL_WIDTH = 300;
        
        function openDialog(d) {
            dStr = 'Modal Example 1<br>More stuff';
            $.pgwModal({
                target: d,
                title: 'Modal title 2',
                maxWidth: 800
            });
        }
        
        //data used to render the HTML templates
        var cards_data = [
            {   image:"image1",
                project:"Project 1!", 
                species:"Some Species",
                date: "12/19/1962" },
            {   image:"image2",
                project:"Project 2!", 
                species:"Some other Species",
                date: "152/24/1962" },
            {   image:"image3",
                project:"Project 3!", 
                species:"A bad Species",
                date: "10/14/1990" },
            {   image:"image4",
                project:"Project 4!", 
                species:"yet another Species",
                date: "5/7/88" }
        ];
          

        //resize event handler
        function onResize() {
            var targetColumns = Math.floor( $(document).width()/MIN_COL_WIDTH );
            if ( columns != targetColumns ) {
                layoutColumns();   
            }
        }
        
        //function to layout the columns
        function layoutColumns() {
            content.detach();
            content.empty();
            
            columns = Math.floor( $(document).width()/MIN_COL_WIDTH );
            
            var columns_dom = [];
            for ( var x = 0; x < columns; x++ ) {
                var col = $('<div class="column">');
                col.css( "width", Math.floor(100/columns)+"%" );
                columns_dom.push( col );   
                content.append(col);
            }
            
            for ( var x = 0; x < cards_data.length; x++ ) {
                var html = compiledCardTemplate( cards_data[x] );
                
                var targetColumn = x % columns_dom.length;
                columns_dom[targetColumn].append( $(html) );    
            }
            $("body").prepend (content);
        }